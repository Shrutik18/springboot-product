package com.api.dto;

public enum CustomerType {
    SILVER, GOLD, PLATINUM
}
